package com.example.personality_analyzer

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this)
        text.text = "شخصيتك\n\nهذا المشروع يحتاج Flutter SDK للبناء الكامل."
        text.textSize = 24f
        text.gravity = android.view.Gravity.CENTER
        setContentView(text)
    }
}
