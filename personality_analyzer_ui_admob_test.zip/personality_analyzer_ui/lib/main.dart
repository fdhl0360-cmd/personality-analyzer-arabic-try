import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(const PersonalityApp());
}

class MusicController {
  MusicController._();
  static final instance = MusicController._();
  final AudioPlayer player = AudioPlayer();
  bool enabled = true;
  bool ready = false;

  Future<void> start() async {
    if (ready) {
      if (enabled) await player.resume();
      return;
    }
    try {
      await player.setReleaseMode(ReleaseMode.loop);
      await player.setVolume(.34);
      await player.setSource(AssetSource('music/36326.mp3'));
      ready = true;
      if (enabled) await player.resume();
    } catch (_) {}
  }

  Future<void> toggle() async {
    enabled = !enabled;
    if (!ready) {
      await start();
      return;
    }
    if (enabled) {
      await player.resume();
    } else {
      await player.pause();
    }
  }

  Future<void> click() async {
    try {
      await SystemSound.play(SystemSoundType.click);
    } catch (_) {}
  }
}

class AdManager {
  AdManager._();
  static final instance = AdManager._();

  // Keep test ads enabled while developing/testing.
  static const bool useTestAd = true;
  static const String testRewardedAdUnitId =
      'ca-app-pub-3940256099942544/5224354917';
  static const String realRewardedAdUnitId =
      'ca-app-pub-3029060433467829/6590686353';

  RewardedAd? _rewardedAd;
  bool _loading = false;

  String get adUnitId => useTestAd ? testRewardedAdUnitId : realRewardedAdUnitId;

  void loadRewarded() {
    if (_rewardedAd != null || _loading) return;
    _loading = true;
    RewardedAd.load(
      adUnitId: adUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _loading = false;
          _rewardedAd = ad;
        },
        onAdFailedToLoad: (error) {
          _loading = false;
          _rewardedAd = null;
        },
      ),
    );
  }

  Future<bool> showRewarded() async {
    final ad = _rewardedAd;
    if (ad == null) {
      loadRewarded();
      return false;
    }

    _rewardedAd = null;
    bool rewarded = false;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        loadRewarded();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        loadRewarded();
      },
    );

    await ad.show(
      onUserEarnedReward: (ad, reward) {
        rewarded = true;
      },
    );
    return rewarded;
  }
}

class PersonalityApp extends StatefulWidget {
  const PersonalityApp({super.key});
  @override State<PersonalityApp> createState() => _PersonalityAppState();
}

class _PersonalityAppState extends State<PersonalityApp> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      MusicController.instance.start();
      AdManager.instance.loadRewarded();
    });
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'اكتشف شخصيتك',
    locale: const Locale('ar', 'IQ'),
    supportedLocales: const [Locale('ar', 'IQ')],
    localeResolutionCallback: (_, __) => const Locale('ar', 'IQ'),
    theme: ThemeData(
      useMaterial3: true,
      colorSchemeSeed: const Color(0xFF6D28D9),
      scaffoldBackgroundColor: const Color(0xFFF7F5FF),
      appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
      cardTheme: CardThemeData(
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      ),
    ),
    home: const HomePage(),
  );
}

class Answer {
  final String text;
  final Map<String,int> scores;
  const Answer(this.text,this.scores);
}
class Question {
  final String text;
  final List<Answer> answers;
  const Question(this.text,this.answers);
}

const dimensions = {
  'social':'التفاعل الاجتماعي',
  'analytical':'التحليل والتفكير',
  'planned':'التخطيط والتنظيم',
  'flexible':'المرونة والتكيف',
  'cooperative':'التعاون',
  'decisive':'الحسم والمبادرة',
};

const questions = <Question>[
  Question('عندما تدخل مكانًا فيه أشخاص لا تعرفهم، ماذا تفعل غالبًا؟',[
    Answer('أبدأ الحديث مع أحدهم بسهولة',{'social':3}),
    Answer('أنتظر قليلًا حتى أشعر بالراحة',{'social':1}),
    Answer('أفضل البقاء هادئًا ومراقبة الجو',{'social':-2}),
    Answer('أفضل الابتعاد عن التجمع',{'social':-3}),
  ]),
  Question('عندما يكون أمامك قرار مهم، ما أسلوبك؟',[
    Answer('أقرر بسرعة',{'decisive':3}),
    Answer('أفكر بالخيارات ثم أقرر',{'analytical':2}),
    Answer('أستشير شخصًا أثق به',{'cooperative':2}),
    Answer('أجمع معلومات كثيرة أولًا',{'analytical':3}),
  ]),
  Question('إذا تغيرت خطتك فجأة، كيف تتعامل مع الأمر؟',[
    Answer('أتأقلم بسرعة',{'flexible':3}),
    Answer('أنزعج قليلًا ثم أتأقلم',{'flexible':1}),
    Answer('أعيد ترتيب الخطة',{'planned':2}),
    Answer('أفضل الالتزام بالخطة الأصلية',{'planned':3,'flexible':-2}),
  ]),
  Question('عندما تعمل ضمن فريق، أي دور تفضله؟',[
    Answer('تنظيم العمل وتوزيع المهام',{'planned':3}),
    Answer('تحليل المشاكل وإيجاد الحلول',{'analytical':3}),
    Answer('التواصل بين أعضاء الفريق',{'social':2,'cooperative':2}),
    Answer('تنفيذ المهام بهدوء',{'cooperative':2}),
  ]),
  Question('إذا أخطأت في شيء، ماذا تفعل؟',[
    Answer('أعترف بالخطأ وأحاول إصلاحه',{'cooperative':3}),
    Answer('أحلل سبب الخطأ',{'analytical':3}),
    Answer('أكمل ولا أتوقف عند الخطأ',{'decisive':2}),
    Answer('أحتاج بعض الوقت قبل التصرف',{'flexible':-1}),
  ]),
  Question('كيف تفضل قضاء وقت فراغك؟',[
    Answer('مع الأصدقاء أو العائلة',{'social':3}),
    Answer('أجرب نشاطات مختلفة',{'flexible':3}),
    Answer('أتعلم شيئًا جديدًا',{'analytical':2}),
    Answer('أقوم بنشاط هادئ ومنظم',{'planned':2}),
  ]),
  Question('عندما تواجه مشكلة معقدة، ماذا تفعل أولًا؟',[
    Answer('أقسم المشكلة وأحللها',{'analytical':3}),
    Answer('أجرب حلًا وأرى النتيجة',{'decisive':2,'flexible':2}),
    Answer('أسأل شخصًا لديه خبرة',{'cooperative':2}),
    Answer('أنتظر حتى تتضح الصورة',{'analytical':1}),
  ]),
  Question('هل تضع خطة قبل البدء بمهمة كبيرة؟',[
    Answer('نعم، بالتفصيل',{'planned':3}),
    Answer('نعم، بشكل مختصر',{'planned':2}),
    Answer('أحيانًا',{'flexible':1}),
    Answer('أفضل أن أبدأ ثم أرتب الأمور',{'flexible':3}),
  ]),
  Question('إذا اختلف معك شخص في الرأي، ماذا تفعل؟',[
    Answer('أحاول فهم وجهة نظره',{'cooperative':3}),
    Answer('أناقش الأدلة والمنطق',{'analytical':3}),
    Answer('أتمسك برأيي إذا كنت مقتنعًا',{'decisive':2}),
    Answer('أنهي النقاش إذا أصبح متوترًا',{'cooperative':1,'flexible':1}),
  ]),
  Question('عندما يكون لديك موعد مهم، ماذا تفعل؟',[
    Answer('أصل مبكرًا',{'planned':3}),
    Answer('أصل في الوقت تقريبًا',{'planned':1}),
    Answer('أترك الأمر للظروف',{'flexible':2}),
    Answer('أتعامل مع الأمور في آخر لحظة',{'flexible':3}),
  ]),
  Question('هل تستمتع بالحديث مع أشخاص جدد؟',[
    Answer('نعم جدًا',{'social':3}),
    Answer('غالبًا نعم',{'social':2}),
    Answer('ليس دائمًا',{'social':-1}),
    Answer('أفضل الأشخاص الذين أعرفهم',{'social':-3}),
  ]),
  Question('إذا كان هناك أكثر من حل للمشكلة، ماذا تفعل؟',[
    Answer('أقارن بينها',{'analytical':3}),
    Answer('أختار الأسرع',{'decisive':3}),
    Answer('أجرب أحدها وأغيره إذا فشل',{'flexible':3}),
    Answer('أطلب رأي شخص آخر',{'cooperative':2}),
  ]),
  Question('كيف تتعامل مع مهامك اليومية؟',[
    Answer('أرتبها حسب الأولوية',{'planned':3}),
    Answer('أنجزها حسب ما يأتي',{'flexible':2}),
    Answer('أبدأ بالأصعب',{'decisive':2}),
    Answer('أطلب المساعدة إذا كانت كثيرة',{'cooperative':2}),
  ]),
  Question('عندما تتعلم شيئًا جديدًا، ماذا تفضل؟',[
    Answer('فهم التفاصيل والأسباب',{'analytical':3}),
    Answer('التطبيق العملي مباشرة',{'decisive':2}),
    Answer('التعلم مع شخص آخر',{'cooperative':2}),
    Answer('التجربة بطرق مختلفة',{'flexible':3}),
  ]),
  Question('إذا دعاك أصدقاؤك لنشاط مفاجئ، ماذا تفعل؟',[
    Answer('أوافق غالبًا',{'social':2,'flexible':3}),
    Answer('أسأل عن التفاصيل أولًا',{'analytical':1}),
    Answer('أرفض إذا كان لدي خطة مسبقة',{'planned':3}),
    Answer('أوافق إذا كان النشاط مناسبًا',{'flexible':1}),
  ]),
  Question('إذا اقترح شخص فكرة مختلفة جدًا، ماذا تفعل؟',[
    Answer('أبحث عن شيء مفيد فيها',{'cooperative':3,'flexible':2}),
    Answer('أقارنها بفكرتي',{'analytical':3}),
    Answer('أدافع عن فكرتي',{'decisive':3}),
    Answer('أجرب ما أراه مناسبًا',{'flexible':2}),
  ]),
  Question('هل تحب أن تعرف ما سيحدث مسبقًا؟',[
    Answer('نعم، أحب التخطيط',{'planned':3}),
    Answer('يفضل، لكن ليس ضروريًا',{'planned':1}),
    Answer('أحب المفاجآت أحيانًا',{'flexible':2}),
    Answer('أفضل ترك الأمور بطبيعتها',{'flexible':3}),
  ]),
  Question('عند العمل مع الآخرين، ما الذي يهمك أكثر؟',[
    Answer('أن يتعاون الجميع',{'cooperative':3}),
    Answer('أن تكون الخطة واضحة',{'planned':2}),
    Answer('أن نصل للنتيجة بسرعة',{'decisive':3}),
    Answer('أن نناقش كل الخيارات',{'analytical':3}),
  ]),
  Question('إذا لم تنجح المحاولة الأولى، ماذا تفعل؟',[
    Answer('أجرب طريقة أخرى',{'flexible':3}),
    Answer('أحلل الخطأ',{'analytical':3}),
    Answer('أحاول مرة ثانية مباشرة',{'decisive':3}),
    Answer('أطلب المساعدة',{'cooperative':3}),
  ]),
  Question('إذا كان لديك وقت طويل قبل موعد المهمة، ماذا تفعل؟',[
    Answer('أبدأ مبكرًا',{'planned':3}),
    Answer('أقسم العمل على أيام',{'planned':3}),
    Answer('أترك بعضه لوقت لاحق',{'flexible':2}),
    Answer('أعمل عندما أشعر أنني مستعد',{'flexible':2}),
  ]),
  Question('في نقاش جماعي، هل تعبر عن رأيك بسهولة؟',[
    Answer('نعم، غالبًا',{'social':3}),
    Answer('إذا كان لدي شيء مهم',{'social':1}),
    Answer('أفضل الاستماع',{'social':-1}),
    Answer('نادراً ما أتكلم أمام مجموعة',{'social':-3}),
  ]),
  Question('عندما تسمع معلومة جديدة، ماذا تفعل؟',[
    Answer('أتحقق منها وأبحث عن دليل',{'analytical':3}),
    Answer('أجربها إذا كانت مناسبة',{'flexible':2}),
    Answer('أسأل شخصًا أثق به',{'cooperative':2}),
    Answer('أستخدمها إذا بدت مفيدة',{'decisive':2}),
  ]),
  Question('إذا كان لديك هدف، كيف تقترب منه؟',[
    Answer('أضع خطوات واضحة',{'planned':3}),
    Answer('أبدأ ثم أعدل الطريق',{'decisive':2,'flexible':2}),
    Answer('أدرس أفضل الطرق',{'analytical':3}),
    Answer('أطلب دعم الآخرين',{'cooperative':3}),
  ]),
  Question('إذا تغيرت الظروف أثناء تنفيذ الخطة، ماذا تفعل؟',[
    Answer('أعدل الخطة وأكمل',{'flexible':3}),
    Answer('أعيد التخطيط',{'planned':3}),
    Answer('أتخذ قرارًا سريعًا',{'decisive':3}),
    Answer('أناقش التغيير مع الفريق',{'cooperative':3}),
  ]),
  Question('ما الذي يساعدك أكثر في فهم مشكلة؟',[
    Answer('تحليل المعلومات',{'analytical':3}),
    Answer('مناقشتها مع الآخرين',{'social':2,'cooperative':2}),
    Answer('تجربة حلول مختلفة',{'flexible':3}),
    Answer('تحديد خطوات واضحة',{'planned':3}),
  ]),
  Question('إذا طلب منك شخص مساعدة وأنت مشغول، ماذا تفعل؟',[
    Answer('أساعده إذا كان الأمر مهمًا',{'cooperative':3}),
    Answer('أحدد وقتًا لاحقًا',{'planned':3}),
    Answer('أقرر بسرعة حسب الموقف',{'decisive':2}),
    Answer('أشرح له كيف يحلها بنفسه',{'analytical':2}),
  ]),
  Question('أي وصف أقرب لطريقتك في اتخاذ القرارات؟',[
    Answer('أفكر ثم أقرر',{'analytical':2}),
    Answer('أقرر ثم أتعامل مع النتائج',{'decisive':3}),
    Answer('أستشير الآخرين',{'cooperative':3}),
    Answer('أترك الخيارات مفتوحة',{'flexible':3}),
  ]),
  Question('كيف تفضل تنظيم أسبوعك؟',[
    Answer('جدول واضح',{'planned':3}),
    Answer('قائمة مهام بسيطة',{'planned':2}),
    Answer('أترك الأيام مفتوحة',{'flexible':3}),
    Answer('أحدد الأشياء المهمة فقط',{'decisive':2}),
  ]),
  Question('عندما تكون في مجموعة، ما الذي يجعلك مرتاحًا؟',[
    Answer('الحديث والتفاعل',{'social':3}),
    Answer('وجود شخص أعرفه',{'social':1}),
    Answer('وجود نشاط أو هدف واضح',{'planned':2}),
    Answer('القدرة على الانسحاب متى أردت',{'flexible':2}),
  ]),
  Question('إذا كان لديك خيار بين طريقة مجربة وطريقة جديدة، ماذا تختار؟',[
    Answer('المجربة لأنها واضحة',{'planned':2,'analytical':1}),
    Answer('الجديدة إذا بدت واعدة',{'flexible':3}),
    Answer('أقارن بينهما أولًا',{'analytical':3}),
    Answer('أختار بسرعة وأبدأ',{'decisive':3}),
  ]),
];

class Result {
  final Map<String,double> values;
  final Map<String,List<int>> evidence;
  const Result(this.values,this.evidence);
}

Result analyze(Map<int,int> selected) {
  final totals = {for(final k in dimensions.keys) k:0.0};
  final maxes = {for(final k in dimensions.keys) k:0.0};
  final evidence = {for(final k in dimensions.keys) k:<int>[]};

  for(final e in selected.entries) {
    final a = questions[e.key-1].answers[e.value];
    for(final s in a.scores.entries) {
      totals[s.key] = totals[s.key]! + s.value;
      maxes[s.key] = maxes[s.key]! + s.value.abs();
      evidence[s.key]!.add(e.key);
    }
  }

  final out = <String,double>{};
  for(final k in dimensions.keys) {
    out[k] = maxes[k] == 0
      ? 50
      : (((totals[k]! / maxes[k]!) + 1) * 50).clamp(0,100);
  }
  return Result(out,evidence);
}

class CharacterProfile {
  final String name;
  final String universe;
  final String emoji;
  final Map<String,double> target;
  final String reason;
  const CharacterProfile(this.name,this.universe,this.emoji,this.target,this.reason);
}

const characters = <CharacterProfile>[
  CharacterProfile('باتمان','DC 🦇','🦇',
    {'social':35,'analytical':92,'planned':88,'flexible':45,'cooperative':48,'decisive':86},
    'تحليل قوي، تخطيط، وحسم عند الحاجة.'),
  CharacterProfile('شيرلوك هولمز','مسلسل Sherlock 🔎','🔎',
    {'social':48,'analytical':98,'planned':62,'flexible':55,'cooperative':35,'decisive':70},
    'فضول وتحليل للتفاصيل وربط الأشياء ببعضها.'),
  CharacterProfile('جيرالت','The Witcher ⚔️','⚔️',
    {'social':38,'analytical':72,'planned':52,'flexible':82,'cooperative':52,'decisive':82},
    'هادئ نسبيًا، عملي، ويتكيف مع الظروف بسرعة.'),
  CharacterProfile('توني ستارك','Marvel 🤖','🤖',
    {'social':82,'analytical':88,'planned':55,'flexible':88,'cooperative':58,'decisive':90},
    'اجتماعي، سريع البديهة، يحب التجربة والحلول غير التقليدية.'),
  CharacterProfile('جويل','The Last of Us 🎒','🎒',
    {'social':42,'analytical':68,'planned':60,'flexible':75,'cooperative':72,'decisive':90},
    'عملي، حذر، ويتحمل المسؤولية عندما يحتاجه الآخرون.'),
  CharacterProfile('لارا كروفت','Tomb Raider 🧭','🧭',
    {'social':60,'analytical':84,'planned':70,'flexible':86,'cooperative':58,'decisive':84},
    'تحليل واستكشاف وتكيف مع المواقف الصعبة.'),
  CharacterProfile('بيتر باركر','Marvel 🕷️','🕷️',
    {'social':78,'analytical':72,'planned':45,'flexible':86,'cooperative':88,'decisive':62},
    'اجتماعي، متعاون، ويتصرف بسرعة حتى لو الخطة مو كاملة.'),
  CharacterProfile('غوردون فريمان','Half-Life 🔬','🔬',
    {'social':28,'analytical':88,'planned':58,'flexible':78,'cooperative':45,'decisive':76},
    'هادئ، تحليلي، ويعتمد على الحلول العملية تحت الضغط.'),
];

CharacterProfile bestCharacter(Result r) {
  double distance(CharacterProfile c) {
    var total = 0.0;
    for (final k in dimensions.keys) {
      total += (r.values[k]! - c.target[k]!).abs();
    }
    return total / dimensions.length;
  }
  return characters.reduce((a,b) => distance(a) < distance(b) ? a : b);
}

String personalityTitle(Result r) {
  final sorted = r.values.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
  final a = sorted[0].key;
  final b = sorted[1].key;
  if (a == 'analytical' && b == 'planned') return 'العقل الاستراتيجي 🧠';
  if (a == 'social' && b == 'cooperative') return 'روح الفريق 😎';
  if (a == 'decisive' && b == 'flexible') return 'الحاسم المرن ⚡';
  if (a == 'planned' && b == 'decisive') return 'القائد المنظّم 👑';
  if (a == 'analytical' && b == 'flexible') return 'المفكر المتكيّف 🔍';
  if (a == 'social' && b == 'flexible') return 'الاجتماعي المغامر 🚀';
  if (a == 'cooperative' && b == 'planned') return 'السند الموثوق 🤝';
  return 'الشخصية المتوازنة ✨';
}

String iraqiComment(Result r) {
  final sorted = r.values.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
  switch (sorted.first.key) {
    case 'analytical':
      return 'واضح مخك ما يضغط زر «إرسال» قبل ما يسوي اجتماع مجلس إدارة 😂';
    case 'planned':
      return 'لو الحياة بيها جدول إكسل، غالبًا إنت مسويه من هسه 😂';
    case 'flexible':
      return 'الخطة عندك مرنة لدرجة حتى الخطة نفسها ما تعرف شنو راح يصير 😂';
    case 'social':
      return 'إذا دخلت مجلس، بعد خمس دقايق تعرف نص الموجودين 😂';
    case 'cooperative':
      return 'الربع يعرفون منو يجيهم وقت الشدة: إنت 🤝😂';
    default:
      return 'إذا صار الموقف جدّي، عندك زر «يلا ننفذ» يشتغل بسرعة ⚡😂';
  }
}

class DecorativeBackground extends StatelessWidget {
  final Widget child;
  final bool dark;
  const DecorativeBackground({super.key,required this.child,this.dark=false});

  @override
  Widget build(BuildContext context) => Stack(
    children:[
      Positioned(top:-70,right:-50,child:_bubble(180, dark ? Colors.white10 : const Color(0x226D28D9))),
      Positioned(bottom:-90,left:-50,child:_bubble(220, dark ? Colors.white.withOpacity(.06) : const Color(0x22256DFF))),
      Positioned(top:210,left:-35,child:_bubble(80, dark ? Colors.white06 : const Color(0x22F59E0B))),
      child,
    ],
  );

  Widget _bubble(double size, Color color) => Container(
    width:size,height:size,
    decoration:BoxDecoration(shape:BoxShape.circle,color:color),
  );
}

class MusicButton extends StatefulWidget {
  const MusicButton({super.key});
  @override State<MusicButton> createState()=>_MusicButtonState();
}
class _MusicButtonState extends State<MusicButton> {
  @override
  Widget build(BuildContext context) => IconButton(
    tooltip: MusicController.instance.enabled ? 'كتم الموسيقى' : 'تشغيل الموسيقى',
    onPressed: () async {
      await MusicController.instance.toggle();
      if (mounted) setState(() {});
    },
    icon: Icon(
      MusicController.instance.enabled ? Icons.music_note_rounded : Icons.music_off_rounded,
      color: Colors.white,
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors:[Color(0xFF312E81),Color(0xFF7C3AED),Color(0xFF0F172A)],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        child: SafeArea(
          child: DecorativeBackground(
            dark:true,
            child: Padding(
              padding:const EdgeInsets.all(24),
              child:Column(
                children:[
                  Align(alignment:Alignment.topLeft,child:const MusicButton()),
                  const Spacer(),
                  TweenAnimationBuilder<double>(
                    tween:Tween(begin:.6,end:1),
                    duration:const Duration(milliseconds:800),
                    curve:Curves.elasticOut,
                    builder:(_,v,child)=>Transform.rotate(
                      angle:(1-v)*.25,
                      child:Transform.scale(scale:v,child:child),
                    ),
                    child:Container(
                      width:150,height:150,
                      decoration:BoxDecoration(
                        shape:BoxShape.circle,
                        color:Colors.white.withOpacity(.14),
                        border:Border.all(color:Colors.white30,width:2),
                        boxShadow:[BoxShadow(color:Colors.black.withOpacity(.18),blurRadius:30)],
                      ),
                      child:const Icon(Icons.psychology_rounded,size:82,color:Colors.white),
                    ),
                  ),
                  const SizedBox(height:28),
                  const Text('اكتشف شخصيتك',
                    style:TextStyle(color:Colors.white,fontSize:35,fontWeight:FontWeight.w900)),
                  const SizedBox(height:10),
                  const Text(
                    '30 سؤالًا • تحليل متنوع • شخصيتك الخيالية الأقرب 🎭',
                    textAlign:TextAlign.center,
                    style:TextStyle(color:Colors.white70,fontSize:16,height:1.6),
                  ),
                  const SizedBox(height:10),
                  const Text('ولا تخاف… ما راح نحكم عليك إذا اخترت «آخر لحظة» 😂',
                    textAlign:TextAlign.center,
                    style:TextStyle(color:Colors.white54,fontSize:13)),
                  const Spacer(),
                  SizedBox(
                    width:double.infinity,height:60,
                    child:FilledButton(
                      style:FilledButton.styleFrom(
                        backgroundColor:Colors.white,
                        foregroundColor:const Color(0xFF5B21B6),
                        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(20)),
                      ),
                      onPressed:() async {
                        await MusicController.instance.click();
                        if (context.mounted) {
                          Navigator.push(context,MaterialPageRoute(builder:(_)=>const QuizPage()));
                        }
                      },
                      child:const Text('ابدأ الاختبار 🚀',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height:16),
                  const Text('حوالي 5 دقائق • اختياراتك هي اللي تحدد النتيجة',
                    style:TextStyle(color:Colors.white60)),
                  const SizedBox(height:20),
                ],
              ),
            ),
          ),
        ),
      ),
    ),
  );
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override State<QuizPage> createState()=>_QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int current=0;
  final selected=<int,int>{};

  void next() async {
    if(!selected.containsKey(current+1)) return;
    await MusicController.instance.click();
    if(!mounted) return;
    if(current<questions.length-1) {
      setState(()=>current++);
    } else {
      Navigator.pushReplacement(context,MaterialPageRoute(
        builder:(_)=>ResultPage(result:analyze(selected)),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final q=questions[current];
    final chosen=selected[current+1];

    return Directionality(
      textDirection:TextDirection.rtl,
      child:Scaffold(
        appBar:AppBar(
          title:const Text('اختبار الشخصية',style:TextStyle(fontWeight:FontWeight.w800)),
          actions:[MusicButton()],
        ),
        body:DecorativeBackground(
          child:Padding(
            padding:const EdgeInsets.fromLTRB(20,10,20,20),
            child:Column(
              crossAxisAlignment:CrossAxisAlignment.stretch,
              children:[
                Row(
                  mainAxisAlignment:MainAxisAlignment.spaceBetween,
                  children:[
                    Text('السؤال ${current+1} من ${questions.length}',
                      style:const TextStyle(fontWeight:FontWeight.bold)),
                    Text('${((current+1)/questions.length*100).round()}%',
                      style:const TextStyle(fontWeight:FontWeight.bold)),
                  ],
                ),
                const SizedBox(height:8),
                TweenAnimationBuilder<double>(
                  key:ValueKey(current),
                  tween:Tween(begin:0,end:(current+1)/questions.length),
                  duration:const Duration(milliseconds:400),
                  builder:(_,v,__)=>
                    ClipRRect(borderRadius:BorderRadius.circular(20),
                      child:LinearProgressIndicator(value:v,minHeight:9)),
                ),
                const SizedBox(height:22),
                AnimatedSwitcher(
                  duration:const Duration(milliseconds:300),
                  transitionBuilder:(child,anim)=>FadeTransition(
                    opacity:anim,
                    child:SlideTransition(
                      position:Tween<Offset>(begin:const Offset(.08,0),end:Offset.zero).animate(anim),
                      child:child,
                    ),
                  ),
                  child:Text(q.text,key:ValueKey(q.text),
                    style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900,height:1.35)),
                ),
                const SizedBox(height:18),
                Expanded(
                  child:ListView.separated(
                    itemCount:q.answers.length,
                    separatorBuilder:(_,__)=>const SizedBox(height:11),
                    itemBuilder:(_,i) {
                      final active=chosen==i;
                      return AnimatedContainer(
                        duration:const Duration(milliseconds:200),
                        decoration:BoxDecoration(
                          color:active?const Color(0xFFF0EAFF):Colors.white,
                          borderRadius:BorderRadius.circular(20),
                          border:Border.all(
                            color:active?const Color(0xFF6D28D9):Colors.black12,
                            width:active?2:1),
                          boxShadow:[BoxShadow(
                            blurRadius:active?14:5,
                            offset:const Offset(0,3),
                            color:Colors.black.withOpacity(.05))],
                        ),
                        child:InkWell(
                          borderRadius:BorderRadius.circular(20),
                          onTap:() async {
                            await MusicController.instance.click();
                            if (mounted) setState(()=>selected[current+1]=i);
                          },
                          child:Padding(
                            padding:const EdgeInsets.all(17),
                            child:Row(children:[
                              AnimatedContainer(
                                duration:const Duration(milliseconds:200),
                                width:29,height:29,
                                decoration:BoxDecoration(
                                  shape:BoxShape.circle,
                                  color:active?const Color(0xFF6D28D9):Colors.transparent,
                                  border:Border.all(color:active?const Color(0xFF6D28D9):Colors.black26,width:2),
                                ),
                                child:active?const Icon(Icons.check,size:17,color:Colors.white):null,
                              ),
                              const SizedBox(width:14),
                              Expanded(child:Text(q.answers[i].text,
                                style:const TextStyle(fontSize:16,fontWeight:FontWeight.w600,height:1.35))),
                            ]),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(
                  height:58,
                  child:FilledButton(
                    onPressed:chosen==null?null:next,
                    child:Text(current==questions.length-1?'حلّل شخصيتي 🧠':'التالي ←',
                      style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ResultPage extends StatelessWidget {
  final Result result;
  const ResultPage({super.key,required this.result});

  String desc(String key) {
    const d={
      'social':'تميل إلى التفاعل والتواصل والمشاركة مع الآخرين.',
      'analytical':'تميل إلى النظر في المعلومات والتفاصيل قبل الوصول للقرار.',
      'planned':'تميل إلى التنظيم ووضع خطوات واضحة قبل تنفيذ المهام.',
      'flexible':'تميل إلى التكيف مع التغييرات وتجربة طرق مختلفة.',
      'cooperative':'تميل إلى التعاون ومراعاة وجهات نظر الآخرين.',
      'decisive':'تميل إلى المبادرة واتخاذ القرارات والتحرك نحو التنفيذ.',
    };
    return d[key]!;
  }

  @override
  Widget build(BuildContext context) {
    final sorted=result.values.entries.toList()
      ..sort((a,b)=>b.value.compareTo(a.value));
    final top=sorted.first;
    final character=bestCharacter(result);

    return Directionality(
      textDirection:TextDirection.rtl,
      child:Scaffold(
        appBar:AppBar(title:const Text('نتيجتك 🎉',style:TextStyle(fontWeight:FontWeight.w900))),
        body:DecorativeBackground(
          child:ListView(
            padding:const EdgeInsets.all(20),
            children:[
              Container(
                padding:const EdgeInsets.all(20),
                decoration:BoxDecoration(
                  gradient:const LinearGradient(colors:[Color(0xFF4C1D95),Color(0xFF7C3AED)]),
                  borderRadius:BorderRadius.circular(26),
                  boxShadow:[BoxShadow(blurRadius:22,color:Colors.deepPurple.withOpacity(.22))],
                ),
                child:Column(children:[
                  const Text('النتيجة الأقرب لشخصيتك',
                    style:TextStyle(color:Colors.white70,fontSize:15)),
                  const SizedBox(height:8),
                  Text(personalityTitle(result),
                    textAlign:TextAlign.center,
                    style:const TextStyle(color:Colors.white,fontSize:28,fontWeight:FontWeight.w900)),
                  const SizedBox(height:18),
                  SizedBox(
                    height:190,
                    child:TweenAnimationBuilder<double>(
                      tween:Tween(begin:0,end:top.value),
                      duration:const Duration(milliseconds:1000),
                      curve:Curves.easeOutCubic,
                      builder:(_,v,__)=>
                        CustomPaint(
                          painter:CirclePainter(v/100,dark:true),
                          child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
                            const Icon(Icons.psychology_rounded,size:38,color:Colors.white),
                            Text('${v.round()}%',style:const TextStyle(color:Colors.white,fontSize:34,fontWeight:FontWeight.w900)),
                            Text(dimensions[top.key]!,style:const TextStyle(color:Colors.white70)),
                          ])),
                        ),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height:16),
              Card(
                color:const Color(0xFFFFF7ED),
                child:Padding(
                  padding:const EdgeInsets.all(17),
                  child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
                    const Text('😂',style:TextStyle(fontSize:28)),
                    const SizedBox(width:10),
                    Expanded(child:Text(iraqiComment(result),
                      style:const TextStyle(fontSize:16,fontWeight:FontWeight.w700,height:1.5))),
                  ]),
                ),
              ),
              const SizedBox(height:20),
              const Text('مؤشرات شخصيتك',
                style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
              const SizedBox(height:12),
              ...sorted.map((e)=>ScoreCard(
                name:dimensions[e.key]!,value:e.value,
                evidence:result.evidence[e.key]??[],
              )),
              const SizedBox(height:8),
              Container(
                padding:const EdgeInsets.all(18),
                decoration:BoxDecoration(
                  color:Colors.white,
                  borderRadius:BorderRadius.circular(22),
                ),
                child:Column(children:[
                  const Text('🎭 الشخصية الخيالية الأقرب',
                    style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
                  const SizedBox(height:12),
                  Text(character.emoji,style:const TextStyle(fontSize:48)),
                  const SizedBox(height:6),
                  Text(character.name,
                    style:const TextStyle(fontSize:26,fontWeight:FontWeight.w900)),
                  Text(character.universe,
                    style:const TextStyle(color:Colors.black54)),
                  const SizedBox(height:10),
                  Text(character.reason,textAlign:TextAlign.center,
                    style:const TextStyle(fontSize:15,height:1.5)),
                  const SizedBox(height:12),
                  Container(
                    padding:const EdgeInsets.symmetric(horizontal:13,vertical:8),
                    decoration:BoxDecoration(
                      color:const Color(0xFFF3E8FF),
                      borderRadius:BorderRadius.circular(30),
                    ),
                    child:const Text('المقارنة ترفيهية ومبنية على إجاباتك، وليست حكمًا علميًا',
                      textAlign:TextAlign.center,
                      style:TextStyle(fontSize:12,color:Color(0xFF6B21A8))),
                  ),
                ]),
              ),
              const SizedBox(height:12),
              Card(child:Padding(
                padding:const EdgeInsets.all(16),
                child:Text('التحليل يعتمد على نمط إجاباتك في هذا الاختبار، وقد تتغير النتيجة إذا تغيرت إجاباتك. ماكو شخصية «أفضل» من الثانية؛ كل نمط إله نقاط قوة مختلفة.',
                  style:const TextStyle(color:Colors.black54,height:1.5)),
              )),
              const SizedBox(height:14),
              FilledButton.icon(
                onPressed:() async {
                  await MusicController.instance.click();
                  if (!context.mounted) return;

                  final rewarded = await AdManager.instance.showRewarded();
                  if (!context.mounted) return;

                  if (rewarded) {
                    Navigator.pushAndRemoveUntil(context,
                      MaterialPageRoute(builder:(_)=>const HomePage()),(_)=>false);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('الإعلان غير متوفر حاليًا، جرّب مرة ثانية بعد لحظات.')),
                    );
                  }
                },
                icon:const Icon(Icons.refresh),
                label:const Text('أعيد الاختبار وأشوف شنو يطلع 😄',
                  style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
              ),
              const SizedBox(height:18),
            ],
          ),
        ),
      ),
    );
  }
}

class ScoreCard extends StatelessWidget {
  final String name;
  final double value;
  final List<int> evidence;
  const ScoreCard({super.key,required this.name,required this.value,required this.evidence});

  @override
  Widget build(BuildContext context)=>Card(
    margin:const EdgeInsets.only(bottom:11),
    child:Padding(
      padding:const EdgeInsets.all(16),
      child:Column(children:[
        Row(children:[
          Expanded(child:Text(name,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold))),
          Text('${value.round()}%',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
        ]),
        const SizedBox(height:10),
        ClipRRect(
          borderRadius:BorderRadius.circular(20),
          child:TweenAnimationBuilder<double>(
            tween:Tween(begin:0,end:value/100),
            duration:const Duration(milliseconds:800),
            builder:(_,v,__)=>
              LinearProgressIndicator(value:v,minHeight:10),
          ),
        ),
        const SizedBox(height:8),
        Align(
          alignment:Alignment.centerRight,
          child:Text('الأسئلة المؤثرة: ${evidence.join('، ')}',
            style:const TextStyle(fontSize:11,color:Colors.black45)),
        ),
      ]),
    ),
  );
}

class CirclePainter extends CustomPainter {
  final double progress;
  final bool dark;
  CirclePainter(this.progress,{this.dark=false});

  @override
  void paint(Canvas canvas,Size size) {
    final c=Offset(size.width/2,size.height/2);
    final r=size.width/2-16;
    final bg=Paint()
      ..style=PaintingStyle.stroke
      ..strokeWidth=14
      ..color=dark?Colors.white24:const Color(0xFFE5E7EB);
    final fg=Paint()
      ..style=PaintingStyle.stroke
      ..strokeWidth=14
      ..strokeCap=StrokeCap.round
      ..color=dark?Colors.white:const Color(0xFF6D28D9);
    canvas.drawCircle(c,r,bg);
    canvas.drawArc(Rect.fromCircle(center:c,radius:r),-math.pi/2,math.pi*2*progress,false,fg);
  }

  @override
  bool shouldRepaint(covariant CirclePainter old)=>old.progress!=progress || old.dark!=dark;
}
